param(
  [string]$ProjectRoot = 'E:\GPT projects\SpatialGround'
)

$ErrorActionPreference = 'Stop'
$SourceRoot = Join-Path $PSScriptRoot 'patch'

if (-not (Test-Path (Join-Path $ProjectRoot 'package.json'))) {
  throw "Astro project not found at: $ProjectRoot"
}

$items = @(
  'src\pages\projects\hawaii-lava-risk.astro',
  'src\styles\lava-risk.css',
  'public\lava-risk\script.js'
)

foreach ($relative in $items) {
  if (-not (Test-Path (Join-Path $SourceRoot $relative))) {
    throw "Patch file missing: $relative"
  }
  if (-not (Test-Path (Join-Path $ProjectRoot $relative))) {
    throw "Current Phase 1 file not found in SpatialGround: $relative"
  }
}

$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$backupRoot = Join-Path $ProjectRoot ".phase2-backup\hawaii-floating-back-$stamp"

foreach ($relative in $items) {
  $src = Join-Path $SourceRoot $relative
  $dst = Join-Path $ProjectRoot $relative
  $backup = Join-Path $backupRoot $relative

  New-Item -ItemType Directory -Force -Path (Split-Path $backup -Parent) | Out-Null
  Copy-Item $dst $backup -Force
  Write-Host "Backed up: $relative"

  New-Item -ItemType Directory -Force -Path (Split-Path $dst -Parent) | Out-Null
  Copy-Item $src $dst -Force
  Write-Host "Installed: $relative"
}

Write-Host "`nPhase 2A floating Back navigation installed." -ForegroundColor Green
Write-Host "Homepage/ring files were NOT changed."
Write-Host "Back target is currently: /#selected-work"
Write-Host "Backup saved to: $backupRoot"
Write-Host "`nRunning Astro production build...`n"

Push-Location $ProjectRoot
try {
  npm run build
  Write-Host "`nBuild passed." -ForegroundColor Green
  Write-Host "Next: npm run dev"
  Write-Host "Open: http://localhost:4321/projects/hawaii-lava-risk/"
  Write-Host "`nGit changes:"
  git status --short
}
finally {
  Pop-Location
}
