param(
  [Parameter(Mandatory=$true)]
  [string]$BackupFolder,
  [string]$ProjectRoot = 'E:\GPT projects\SpatialGround'
)

$ErrorActionPreference = 'Stop'
$items = @(
  'src\pages\projects\hawaii-lava-risk.astro',
  'src\styles\lava-risk.css',
  'public\lava-risk\script.js'
)

if (-not (Test-Path $BackupFolder)) {
  throw "Backup folder not found: $BackupFolder"
}

foreach ($relative in $items) {
  $src = Join-Path $BackupFolder $relative
  $dst = Join-Path $ProjectRoot $relative
  if (-not (Test-Path $src)) { throw "Backup file missing: $relative" }
  Copy-Item $src $dst -Force
  Write-Host "Restored: $relative"
}

Write-Host "`nRollback complete. Running build..." -ForegroundColor Yellow
Push-Location $ProjectRoot
try { npm run build }
finally { Pop-Location }
