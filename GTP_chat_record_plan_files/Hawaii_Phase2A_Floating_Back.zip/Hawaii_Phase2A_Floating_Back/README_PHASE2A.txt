Hawaiʻi Lava Project — Phase 2A Floating Back Navigation
========================================================

PURPOSE
Test the responsive floating "Back to Selected Work" control without changing
or redesigning the stable Hawaiʻi case-study baseline or the 9-card homepage.

BEHAVIOR
Desktop
- Hidden on the opening hero area.
- Appears after the visitor scrolls into the story.
- While scrolling: fades to ~8% opacity and cannot be clicked accidentally.
- After ~800 ms of no scrolling: returns to ~94% opacity.
- Fixed at the bottom center.

Mobile (<= 650 px)
- Hidden on the opening hero area.
- When idle: slides out at the lower-left.
- While scrolling: tucks into the left edge, leaving a small arrow handle visible.
- After ~800 ms of no scrolling: slides back out.
- Respects bottom safe-area inset.

Map dialog
- Floating control hides while the full-map dialog is open.

Reduced motion
- Transition animation is disabled when the visitor prefers reduced motion.

TARGET
The button currently links to:
  /#selected-work

The homepage is NOT modified in this patch. If the homepage does not yet contain
id="selected-work", the link still returns to the homepage, but the exact ring
anchor will be wired in the next step after this interaction is approved.

INSTALL
1. Extract this ZIP anywhere outside the SpatialGround folder.
2. Open PowerShell in this extracted folder.
3. Run:

   powershell -ExecutionPolicy Bypass -File ".\install-phase2a-floating-back.ps1"

Default SpatialGround project path:
  E:\GPT projects\SpatialGround

The installer backs up the three current Phase 1 files before replacing them,
then runs npm run build.

FILES CHANGED
- src/pages/projects/hawaii-lava-risk.astro
- src/styles/lava-risk.css
- public/lava-risk/script.js

FILES NOT CHANGED
- src/pages/index.astro
- homepage 9-card ring
- project content/maps/assets

EXTRA CLEANUP
The patch also replaces the old relative hero CSS URL with the public Astro URL:
  /lava-risk/assets/main-map.jpg
This removes the earlier build warning without changing the visual design.
