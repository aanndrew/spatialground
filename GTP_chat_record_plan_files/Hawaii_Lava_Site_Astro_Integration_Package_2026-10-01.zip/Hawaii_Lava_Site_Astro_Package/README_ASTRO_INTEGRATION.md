# Hawaiʻi Lava Risk Site — Astro Integration Package

This archive contains the complete source and assets from the ChatGPT Site, plus an Astro-ready page for integration into the existing SpatialGround project.

## Package structure

```text
Hawaii_Lava_Site_Astro_Package/
├── original-static-site/
│   ├── index.html
│   ├── styles.css
│   ├── script.js
│   └── assets/
├── astro-integration/
│   ├── src/pages/projects/hawaii-lava-risk.astro
│   ├── src/styles/lava-risk.css
│   └── public/lava-risk/
│       ├── script.js
│       └── assets/
└── project-notes/
    ├── SITE_COPY_DRAFT_V1.md
    ├── DATA_AND_CLAIMS_AUDIT.md
    ├── SITE_BLUEPRINT.md
    └── other planning notes
```

## Fastest integration into SpatialGround

From the root of the existing Astro repository, copy the contents of `astro-integration/` into matching folders:

- `src/pages/projects/hawaii-lava-risk.astro` → the Astro project’s `src/pages/projects/`
- `src/styles/lava-risk.css` → `src/styles/`
- `public/lava-risk/` → `public/lava-risk/`

After copying, the project page should be available at:

```text
/projects/hawaii-lava-risk/
```

No npm package is required for the page. The interaction uses browser-native JavaScript.

## Important integration notes

1. The supplied Astro page is deliberately self-contained and includes its own `<html>`, `<head>`, navigation, footer, and metadata.
2. If SpatialGround already has a shared layout, replace the page-level `<html>`, `<head>`, top navigation, and footer with the existing layout component.
3. Keep the section IDs—`overview`, `context`, `methods`, `findings`, and `warnings`—because the navigation links depend on them.
4. Keep the map filenames unchanged unless the corresponding `data-map` attributes and JavaScript paths are also updated.
5. The CSS defines general selectors such as `body`, `h1`, `footer`, and `.topbar`. When embedding inside the main portfolio layout, scope them under a wrapper such as `.lava-risk-page` to prevent conflicts with the nine-card portfolio styles.
6. The fixed `.topbar` belongs to the standalone case study. Remove it if SpatialGround already supplies global navigation.
7. The original Site is presentation-only and does not use a database, authentication, API, or external JavaScript library.

## Recommended SpatialGround architecture

For the existing rotating-card portfolio, use the Hawaiʻi card to link to:

```text
/projects/hawaii-lava-risk/
```

Keep the ring/card animation on the portfolio homepage. Load the full StoryMap-style case study only after the visitor selects the Hawaiʻi project. This prevents the heavier map images and long-form styles from affecting the homepage.

## Suggested later refactor

The first migration can remain as one Astro page. After it works, split it into components:

```text
src/components/lava-risk/
├── LavaHero.astro
├── KeyStats.astro
├── HazardContext.astro
├── MapExplorer.astro
├── MethodsWorkflow.astro
├── Findings.astro
└── WarningPanel.astro
```

This refactor is optional. It is safer to verify the single-page migration first.

## Evidence boundary

The project notes are included because the website language depends on specific evidence rules:

- Use “parcel features,” not households or unique owners.
- Keep the 2025 analysis date visible.
- Describe lava-flow hazard zones as long-term relative hazard, not eruption predictions.
- Label hypothetical scenarios as planning exercises rather than forecasts.

## Original hosted version

The standalone hosted version remains available at:

https://hawaii-lava-risk.aanndrew-aanndrew.chatgpt.site/

