# Site Blueprint

## 1. Positioning

This will be a single-page, scroll-driven GIS and environmental-policy case study. It should demonstrate the ability to:

- conduct and explain spatial analysis;
- communicate hazard exposure to nontechnical audiences;
- connect GIS results to land-use planning and emergency preparedness;
- identify environmental-justice and community-resilience considerations; and
- develop evidence-based, implementable policy recommendations.

## 2. Intended audience

- FEMA and emergency-management hiring teams
- GIS Analyst hiring teams
- Environmental planners and policy analysts
- County, state, and federal agencies
- DOI, BLM, and other land-management organizations

## 3. Narrative structure

### Section 1 — Opening and Executive Overview

The first screen should immediately show the study area, research purpose, analyst name, and three principal figures:

- 135,471 parcel features analyzed
- 24,528 parcel features intersecting Zones 1 and 2
- 4,183 parcel features intersecting Zone 1

### Section 2 — Why Lava Risk Matters

Explain why lava hazards affect homes and property, roads and evacuation, public facilities, insurance, development decisions, land use, and community resilience.

### Section 3 — Study Area and Hazard Context

Introduce Hawaiʻi Island, volcanoes, principal communities, Lava Hazard Zones 1–9, and selected historic lava-flow events. Use an interactive or carefully staged map where the available data supports it.

### Section 4 — Data and GIS Methods

Explain the datasets, publication years, coordinate system, spatial-overlay or selection process, exposure classification, and limitations.

Proposed workflow:

1. Lava hazard zones
2. Parcel boundaries
3. Supporting community data
4. Spatial overlay
5. Exposure by hazard zone
6. Planning and policy priorities

### Section 5 — Key Findings

Present the exposure results through a parcel map, summary statistics, a hazard-zone comparison chart, and optional clickable geographic details. Separate measured findings from policy interpretation.

### Section 6 — Community Exposure and Equity

Consider evacuation access, remote communities, income and insurance burdens, older adults and mobility, language access, and Native Hawaiian cultural resources.

Do not present these as measured findings unless supporting data have been analyzed. Clearly label unmeasured topics as planning considerations or opportunities for further analysis.

### Section 7 — Policy Options

Compare, rather than merely list, potential responses:

| Policy option | Principal benefit | Potential limitation |
|---|---|---|
| Restrict new development in high-risk areas | Reduces future exposure | Land rights and housing concerns |
| Improve evacuation routes | Strengthens emergency response | Cost and terrain constraints |
| Voluntary acquisition or relocation | Reduces long-term exposure | Funding and community acceptance |
| Building and land-use standards | May reduce some losses | Cannot stop lava flows |
| Warning and community education | Relatively broad, lower-cost reach | Does not remove physical exposure |

### Section 8 — Priority Recommendations

Initial recommendation framework:

1. Prioritize evacuation-capacity assessment in Zones 1 and 2.
2. Integrate parcel exposure with current population and critical-infrastructure data.
3. Apply risk-informed land-use planning in the highest-hazard areas.
4. Co-design warning and relocation policies with affected communities.
5. Establish a schedule for updating parcel, road, infrastructure, and demographic data.

Recommendations must be reviewed after the evidence and current policy context are verified.

### Section 9 — Limitations, Sources, and About the Analyst

Include dataset sources and publication years, methodological limits, the distinction between a hazard zone and a short-term eruption forecast, and the distinction between parcel counts and population.

Finish with the analyst's MS Environmental Policy & Management and Graduate Certificate in GIS background, relevant technical and policy skills, contact information, and an optional downloadable report.

## 4. Visual direction

- Professional, restrained hazard-planning aesthetic
- Dark volcanic charcoal, lava orange, muted earth tones, and high-contrast text
- Large map-led opening rather than a generic marketing page
- Clear typography and accessible color contrast
- Responsive presentation for desktop and mobile
- Limited decorative imagery; maps, analytical graphics, and evidence should lead the design

## 5. Functional scope for the first release

Include only functions that strengthen the case study:

- scroll-driven narrative sections;
- interactive or staged maps where verified data are available;
- hazard-zone legend and layer controls when useful;
- key-statistic cards;
- one or more analytical charts;
- citations, limitations, and analyst profile; and
- optional final-report download.

Do not add accounts, search, databases, visitor forms, or unrelated portfolio features in the first release.
