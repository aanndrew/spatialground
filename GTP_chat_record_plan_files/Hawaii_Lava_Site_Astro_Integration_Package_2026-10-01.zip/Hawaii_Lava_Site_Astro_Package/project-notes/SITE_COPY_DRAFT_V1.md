# Website Copy Draft — Version 1

## Editorial note

This document contains the first approved-content draft for the opening, hazard context, methods, verified findings, and official warning panel. The language is written for a professional portfolio audience and can be shortened during visual layout. Statistics describe the 2025 GIS analysis and should retain that date wherever displayed.

---

## Navigation labels

- Overview
- Hazard Context
- Methods
- Findings
- Monitoring & Warnings
- Policy
- Limitations
- About

---

## 1. Hero / Opening

### Eyebrow

GIS + Environmental Policy Case Study

### Title

Lava-Flow Risk, Community Exposure, and Hazard-Mitigation Policy on Hawaiʻi Island

### Subtitle

A GIS-based decision-support case study for land-use planners, emergency managers, and community stakeholders.

### Opening summary

Volcanic hazards are inseparable from planning on Hawaiʻi Island. This case study uses parcel boundaries and U.S. Geological Survey lava-flow hazard zones to identify where property records intersect the island’s two highest long-term hazard classifications. It then translates the spatial results into questions for land-use planning, emergency preparedness, infrastructure analysis, and community resilience.

### Key figures

**135,471**  
Parcel features analyzed

**24,528**  
Parcel features intersecting Zones 1 or 2

**4,183**  
Parcel features intersecting Zone 1

### Figure note

Results from the 2025 GIS analysis. Counts represent parcel features, not population, structures, households, or unique owners.

### Primary action

Explore the Analysis

### Secondary action

View Methods

---

## 2. Executive Overview

### Heading

From hazard boundaries to planning priorities

### Body copy

Hawaiʻi Island’s lava-flow hazard zones provide an island-wide framework for understanding relative long-term exposure. Yet a hazard map alone does not show how many parcel records cross the highest-hazard areas or how those intersections may affect planning decisions.

This project combines lava-flow hazard zones with county parcel geometry. The analysis found that 24,528 parcel features—18.1% of the 135,471 features evaluated—intersected Zones 1 or 2. Within that group, 4,183 parcel features—3.1% of all features analyzed—intersected Zone 1.

These results do not predict where or when an eruption will occur. Instead, they provide a screening-level view of long-term exposure that can help agencies and communities identify where more detailed analysis may be warranted.

### Decision-support callout

The value of this analysis is not a single parcel count. Its value is the ability to connect a transparent spatial method with practical questions: Where should evacuation capacity receive closer review? Which public facilities and road connections merit updated analysis? How should long-term hazard information inform future development without treating a generalized hazard boundary as parcel-level certainty?

---

## 3. Why Lava Risk Matters

### Heading

Lava risk is also a land-use and community-resilience issue

### Body copy

Lava flows can damage homes, roads, utilities, and public facilities, but the planning challenge extends beyond the physical flow footprint. Communities may also face disrupted transportation, reduced access to services, housing and insurance pressures, and difficult choices about rebuilding or future development.

These effects are not distributed evenly. Remote communities, older adults, households with limited transportation, people who need language-access support, and residents with strong cultural or economic ties to place may experience different constraints during preparation, evacuation, recovery, or relocation.

The present GIS analysis measures parcel–hazard-zone intersections. It does not measure demographic vulnerability or infrastructure performance. Those subjects are treated here as planning priorities for a future phase, not as findings already established by the parcel analysis.

### Three planning lenses

**Exposure**  
Which parcel features intersect the highest long-term lava-flow hazard zones?

**Access**  
Which road connections, evacuation options, and essential services require closer evaluation?

**Capacity**  
Which communities and agencies may need additional resources for warning, evacuation, recovery, or long-term adaptation?

---

## 4. Study Area and Hazard Context

### Heading

An island shaped by active volcanism

### Body copy

The present landmass of Hawaiʻi Island is formed by five volcanoes: Kohala, Mauna Kea, Hualālai, Mauna Loa, and Kīlauea. The U.S. Geological Survey’s Hawaiian Volcano Observatory monitors volcanic activity in Hawaiʻi and provides scientific information, maps, notices, and updates for public officials and communities.

The island-wide lava-flow hazard map divides Hawaiʻi Island into nine zones. Zone 1 is the highest-hazard classification and includes the summits and rift zones of Kīlauea and Mauna Loa, where vents have repeatedly formed. Zone 2 generally includes areas adjacent to and downslope of active rift zones. Higher zone numbers indicate progressively lower relative long-term hazard.

### Essential interpretation

Hazard zones describe relative long-term lava-flow hazard. They are not evacuation zones, insurance ratings, parcel-specific risk determinations, or short-term forecasts of the next eruption.

### Suggested map interaction

- Default view: full island with Zones 1–9.
- First step: highlight Zones 1 and 2.
- Second step: add selected parcel features.
- Optional labels: principal communities and volcanoes.
- Source note: USGS lava-flow hazard framework; parcel analysis completed in 2025.

### Volcano terminology note

Kamaʻehuakanaloa, formerly called Lōʻihi, is an active submarine volcano southeast of Hawaiʻi Island. It should be described separately rather than substituted for Kohala in the list of five volcanoes forming the present island.

---

## 5. Data and GIS Methods

### Heading

A reproducible spatial-intersection workflow

### Research question

How many Hawaiʻi County parcel features intersect U.S. Geological Survey Lava-Flow Hazard Zones 1 and 2, and what planning questions emerge from that spatial pattern?

### Workflow

1. Compile the Hawaiʻi County parcel layer and lava-flow hazard-zone polygons.
2. Maintain the project data in the Hawaiʻi State Plane coordinate system used by the submitted analysis (EPSG:3750).
3. Select parcel features whose geometries intersect Zones 1 or 2.
4. Create a separate subset for parcel features intersecting Zone 1.
5. Review counts, identifiers, map outputs, and project-layer connections.
6. Interpret the results as screening-level evidence for planning—not as an eruption prediction or structure-loss estimate.

### Method statement

Parcels were selected where their geometries intersected the boundaries of USGS Lava-Flow Hazard Zones 1 and 2. Because a parcel can cross a generalized hazard-zone boundary, an intersection does not mean that the entire parcel lies inside the same zone.

### Data table

| Dataset | Role in analysis | First-release treatment |
|---|---|---|
| Lava-flow hazard zones | Long-term relative hazard classification | Core analytical layer |
| Hawaiʻi County parcels | Units used for spatial intersection | Core analytical layer |
| County boundary | Study-area context | Supporting layer |
| Roads, hospitals, and shelters | Emergency-planning context | Reconnect to verified official services |
| Fire stations | Emergency-planning context | Re-source before publishing |
| Volcano boundaries and locations | Geographic context | Rebuild with current terminology |

### Quality-control note

The source data contain 135,471 parcel features and 135,411 unique TMK-like identifiers. The website therefore reports parcel **features**, not unique properties or ownership units. The Zone 1 subset contains 4,183 features with unique identifiers.

---

## 6. Key Findings

### Heading

Nearly one in five parcel features intersected Zones 1 or 2

### Finding 1

**24,528 parcel features intersected Lava-Flow Hazard Zones 1 or 2.**

This represents 18.1% of the 135,471 parcel features evaluated in the 2025 analysis. The figure identifies the scale of parcel geometry overlapping the island’s two highest long-term hazard classifications.

### Finding 2

**4,183 parcel features intersected Zone 1.**

This represents 3.1% of all parcel features analyzed. Zone 1 includes summit and rift-zone areas associated with Kīlauea and Mauna Loa and is the highest classification in the USGS lava-flow hazard framework.

### Relationship between the figures

The 4,183 Zone 1 features are included within the 24,528 features intersecting Zones 1 or 2. They should not be added together.

### Interpretation

The results identify where more detailed planning analysis may be most valuable. A next phase could integrate current roads, travel constraints, population and household characteristics, structures, critical facilities, and community-defined priorities.

### What the findings do not mean

- They do not represent 24,528 homes or households.
- They do not show the number of residents exposed.
- They do not estimate the probability of an eruption during a particular year.
- They do not mean that every part of an intersecting parcel has the same hazard classification.
- They do not establish that a road, hospital, shelter, or fire station will be inaccessible during an event.

### Chart labels

**All parcel features analyzed:** 135,471  
**Intersecting Zones 1 or 2:** 24,528 / 18.1%  
**Intersecting Zone 1:** 4,183 / 3.1%

---

## 7. Monitoring, Warnings, and Scenario Planning

### Heading

Three kinds of information—three different decisions

### Introductory copy

Hazard communication becomes confusing when long-term maps, current monitoring, and hypothetical planning exercises are presented as if they answer the same question. The site should keep them visually and verbally separate.

### Panel A — Long-term hazard

**Question answered:** Which areas have higher or lower relative lava-flow hazard over the long term?

Use the USGS Lava-Flow Hazard Zones 1–9. These zones support land-use discussion, public education, and screening-level analysis. They do not predict the location or timing of the next eruption.

### Panel B — Current official status

**Question answered:** What are the responsible agencies reporting now?

For current conditions, users should follow official USGS Hawaiian Volcano Observatory updates and local or state emergency-management instructions. The website should link to these sources rather than manually presenting a status that may become outdated.

Suggested links:

- USGS Hawaiian Volcano Observatory: https://www.usgs.gov/observatories/hvo
- USGS Kīlauea updates: https://www.usgs.gov/volcanoes/kilauea/volcano-updates
- USGS Mauna Loa updates: https://www.usgs.gov/volcanoes/mauna-loa/volcano-updates
- Hawaiʻi County Civil Defense: https://www.hawaiicounty.gov/departments/civil-defense
- Hawaiʻi Emergency Management Agency warning system: https://dod.hawaii.gov/hiema/all-hazard-statewide-outdoor-warning-siren-system/

### Panel C — Planning scenarios

**Question answered:** How might agencies and communities test preparedness under a defined hypothetical event?

Scenario maps may be useful for examining evacuation access, road disruption, shelter demand, or continuity of essential services. Every scenario must document its assumptions, data date, model limitations, and intended planning use.

### Required scenario disclaimer

> Planning scenario—not an eruption forecast. This illustration is for preparedness analysis and does not predict the location, timing, or extent of a future lava flow.

### Emergency-information notice

This portfolio is an analytical case study, not an emergency-notification service. During an emergency, follow instructions from Hawaiʻi County Civil Defense, the Hawaiʻi Emergency Management Agency, and the U.S. Geological Survey.

---

## 8. Transition to the Policy Section

### Heading

Exposure mapping is the beginning of the decision process

### Body copy

The verified parcel results establish where long-term hazard and property geography overlap. They do not determine a single policy response. The next section will compare options involving land-use planning, evacuation capacity, infrastructure analysis, community engagement, warning access, and voluntary long-term risk reduction.

Policy recommendations will distinguish actions supported directly by the present analysis from actions that require additional demographic, infrastructure, financial, legal, or community-based evidence.

---

## 9. Source and Date Footer for These Sections

Parcel statistics: 2025 GIS analysis by Chi Ho; results reproduced from the submitted file geodatabase.  
Hazard context: U.S. Geological Survey, Hawaiian Volcano Observatory.  
Emergency-information links: official agency pages; users should confirm current conditions directly with the responsible agencies.  
Draft prepared for portfolio-site development in September 2026.

## Primary reference links

- https://www.usgs.gov/observatories/hvo/frequently-asked-questions-and-answers-about-lava-flow-hazards
- https://www.usgs.gov/observatories/hvo/science/lava-flow-hazards-zones-and-flow-forecast-methods-island-hawaii
- https://www.usgs.gov/observatories/hvo/active-volcanoes-hawaii
- https://www.usgs.gov/volcanoes/kilauea/science/geology-and-history
- https://www.usgs.gov/observatories/hvo
- https://www.hawaiicounty.gov/departments/civil-defense
- https://dod.hawaii.gov/hiema/all-hazard-statewide-outdoor-warning-siren-system/

