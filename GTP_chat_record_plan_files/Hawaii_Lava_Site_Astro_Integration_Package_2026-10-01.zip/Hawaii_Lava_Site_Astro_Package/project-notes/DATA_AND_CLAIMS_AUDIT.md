# Data and Claims Audit

## Status

This audit establishes the evidence base for the first website version. It separates reproduced GIS results from background context, live warning information, planning scenarios, and claims that still require further analysis.

## 1. Results verified from the submitted geodatabase

| Website statement | Verified value | Evidence status | Approved wording |
|---|---:|---|---|
| Parcel features analyzed | 135,471 | Confirmed 2025 result | “The 2025 analysis evaluated 135,471 parcel features across Hawaiʻi County.” |
| Parcel features intersecting Lava-Flow Hazard Zones 1 and 2 | 24,528 (18.1%) | Confirmed 2025 result | “24,528 parcel features—18.1% of those analyzed—intersected Zones 1 or 2.” |
| Parcel features intersecting Zone 1 | 4,183 (3.1%) | Confirmed 2025 result | “4,183 parcel features—3.1% of those analyzed—intersected Zone 1.” |
| Selection rule | Geometry intersects hazard-zone boundary | Confirmed method | “Parcels were selected where their geometries intersected USGS Lava-Flow Hazard Zones 1 and 2.” |
| Coordinate reference system | EPSG:3750 | Confirmed method | State in the methods/data note, not the opening narrative. |

The Zone 1 result is a subset of the combined Zones 1 and 2 result. Counts refer to parcel **features or records**, not people, households, buildings, assessed value, or unique property owners.

## 2. Important identifier caveat

The source parcel layer contains 135,471 features but 135,411 unique TMK-like identifiers. The combined Zones 1 and 2 output contains 24,528 features but 24,524 unique identifiers. All 4,183 Zone 1 features have unique identifiers.

The website should therefore use “parcel features” or “parcel records” for the headline statistics. It should not imply that every feature represents one unique ownership unit.

## 3. What the analysis does—and does not—show

### Supported conclusions

- A substantial share of parcel geometry intersects the two highest long-term lava-flow hazard zones.
- Zone 1 exposure is concentrated around the summits and rift zones of Kīlauea and Mauna Loa.
- The results can support screening, prioritization, and follow-up analysis for land-use and emergency-planning decisions.

### Conclusions not yet supported

- Number of residents, homes, businesses, or structures exposed.
- Estimated financial loss or insurance impact.
- Adequacy of a specific evacuation route.
- Number of hospitals, shelters, fire stations, or road segments inside each zone.
- Disproportionate effects on a particular demographic group.
- Where or when the next eruption will occur.

These topics may appear as planning considerations or future-analysis priorities, but not as measured findings.

## 4. Required corrections to the original project narrative

| Original issue | Required website treatment |
|---|---|
| “At immediate risk” | Replace with “intersecting the highest long-term lava-flow hazard zones” or “with long-term relative exposure.” |
| Hazard zones described as predictions | Explain that USGS zones show relative long-term hazard; they are not short-term eruption forecasts. |
| Hawaiʻi Island volcano list omits Kohala and includes offshore Lōʻihi | For the five volcanoes that form the present island, use Kohala, Mauna Kea, Hualālai, Mauna Loa, and Kīlauea. Treat Kamaʻehuakanaloa (formerly Lōʻihi) separately as an offshore submarine volcano. |
| Mauna Loa last eruption shown as 1984 | Update to include the 2022 eruption. |
| Kīlauea described as continuously erupting “1983 to present” | State that the Puʻuʻōʻō eruption lasted from 1983 to 2018 and that later summit eruptions were separate episodes. Avoid hard-coding live status into the static narrative. |
| Lōʻihi shown as erupting “1996 to present” | Remove. Use the current name Kamaʻehuakanaloa and an official-source description if included. |
| `Extracted_harzard_zone` | Correct the display label to “Extracted hazard zones”; preserve the original source data unchanged. |

## 5. Warning and scenario-planning framework

The site should use a three-part distinction:

1. **Long-term hazard:** USGS Lava-Flow Hazard Zones 1–9.
2. **Current official status:** links to USGS Hawaiian Volcano Observatory updates and Hawaiʻi County/State emergency alerts.
3. **Planning scenarios:** clearly labeled hypothetical exercises used to test evacuation, road access, and service continuity.

Approved disclaimer for a scenario map:

> Planning scenario—not an eruption forecast. This illustration is for preparedness analysis and does not predict the location, timing, or extent of a future lava flow.

Do not reproduce a live status manually if an official link or dated feed can be shown instead. Live conditions can change after publication.

## 6. Map disposition

| Map or layer | First-release treatment | Reason |
|---|---|---|
| Island-wide hazard context | Rebuild as a clean interactive map | Best way to explain Zones 1–9 without dense parcel outlines. |
| Parcels intersecting Zones 1 and 2 | Rebuild as the principal analytical map | Central verified finding; enable zone toggles and concise pop-ups. |
| Original four exported maps | Include selectively as “original project outputs” | Useful evidence of the completed coursework, but legends and labels are too dense for the primary web experience. |
| Roads, hospitals, and shelters | Reconnect to official services and date-stamp | Existing ArcGIS project contains recoverable service connections. |
| Fire stations | Re-source before publishing | The submitted local fire-station layer is empty and points to a missing external geodatabase. |
| Volcano overview | Rebuild | Original labels contain outdated eruption information. |
| Hypothetical flow or evacuation scenario | Defer until assumptions are documented | Must not be mistaken for an official forecast. |

## 7. Data provenance recovered from the ArcGIS project

- Lava hazard zones: State of Hawaiʻi geodata service, Hazards MapServer, layer 3.
- Parcel boundaries: State of Hawaiʻi geodata service, Parcels/Zoning MapServer, layer 5.
- Hospitals: State of Hawaiʻi geodata service, Infrastructure MapServer, layer 5.
- Emergency shelters: Hawaiʻi Emergency Shelters FeatureServer, layer 0.
- Fire stations: original connection unresolved; must be replaced with a verified public source.

Before use in the live site, each service will be checked for availability, metadata, publication date, field definitions, and reuse terms.

## 8. Authoritative context sources

- USGS, “Frequently Asked Questions and Answers about Lava-Flow Hazards”: https://www.usgs.gov/observatories/hvo/frequently-asked-questions-and-answers-about-lava-flow-hazards
- USGS, “Lava Flow Hazards Zones and Flow Forecast Methods, Island of Hawaiʻi”: https://www.usgs.gov/observatories/hvo/science/lava-flow-hazards-zones-and-flow-forecast-methods-island-hawaii
- USGS, “Active Volcanoes of Hawaiʻi”: https://www.usgs.gov/observatories/hvo/active-volcanoes-hawaii
- USGS, “Geology and History of Kīlauea”: https://www.usgs.gov/volcanoes/kilauea/science/geology-and-history
- USGS, Hawaiian Volcano Observatory: https://www.usgs.gov/observatories/hvo
- Hawaiʻi Emergency Management Agency, statewide outdoor warning siren system: https://dod.hawaii.gov/hiema/all-hazard-statewide-outdoor-warning-siren-system/

## 9. Decision gate before site construction

The evidence base is sufficient to begin a first meaningful site version. The build should start with:

1. opening and executive overview;
2. study-area and hazard context;
3. verified methods;
4. the two parcel-exposure findings; and
5. a warning/status panel that directs users to official sources.

Community-equity metrics, infrastructure counts, and predictive scenarios should be added only after their own datasets and methods are verified.
