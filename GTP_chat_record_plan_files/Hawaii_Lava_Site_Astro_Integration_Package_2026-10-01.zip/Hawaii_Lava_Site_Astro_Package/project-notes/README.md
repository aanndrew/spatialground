# Hawaiʻi Lava Risk Story Site — Project Package

## Project purpose

This package defines the structure for a professional GIS and environmental-policy portfolio site based on Chi Ho's 2025 Hawaiʻi Island lava-flow hazard analysis.

The site will present the project as a decision-support case study for land-use planners, emergency managers, public agencies, and community stakeholders. It is intended to support applications for FEMA, GIS Analyst, Environmental Planner, Hazard Mitigation, and Environmental Policy roles.

## Working title

**Lava-Flow Risk, Community Exposure, and Hazard-Mitigation Policy on Hawaiʻi Island**

**Subtitle:** A GIS-based decision-support case study for land-use planners, emergency managers, and community stakeholders.

## Current confirmed findings

- 135,471 parcel features analyzed
- 24,528 parcel features intersecting Lava-Flow Hazard Zones 1 and 2
- 4,183 parcel features intersecting Lava-Flow Hazard Zone 1

These figures are from the original 2025 analysis and must be labeled accordingly unless they are reproduced with updated datasets.

## Package contents

- `SITE_BLUEPRINT.md` — audience, narrative flow, page sections, and presentation strategy
- `DATA_AND_CONTENT_CHECKLIST.md` — files, sources, verification rules, and build stages
- `DATA_AND_CLAIMS_AUDIT.md` — verified results, approved wording, factual corrections, warning/scenario rules, and map priorities
- `SITE_COPY_DRAFT_V1.md` — first English website-copy draft for the opening, context, methods, findings, and warning panel

## Project status

**Core content drafted; first site build next.** The submitted materials and geodatabase have been reviewed, the principal parcel results reproduced, the evidence boundary defined, and the first English website-copy draft completed. No website has been built or published yet.
