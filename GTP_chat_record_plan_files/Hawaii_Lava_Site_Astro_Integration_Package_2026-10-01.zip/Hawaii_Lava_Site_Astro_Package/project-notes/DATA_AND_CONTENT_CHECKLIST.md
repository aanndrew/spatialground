# Data and Content Checklist

## 1. Original project materials

Provide as many of the following as are available:

- final paper or report, preferably PDF or DOCX;
- exported map images;
- presentation slides;
- tables showing parcel counts by hazard zone;
- ArcGIS project or project package;
- file geodatabase;
- shapefiles in complete ZIP packages;
- GeoPackage, GeoJSON, KML, or CSV outputs;
- original citations or bibliography; and
- assignment instructions or grading feedback, if relevant.

The project can begin with only the report and map images. GIS source files are helpful but not mandatory for the first site version.

## 2. Dataset inventory

For every dataset, record:

- official title;
- publishing organization;
- source URL;
- publication or revision year;
- date downloaded;
- geographic coverage;
- coordinate system;
- fields used in the analysis;
- transformations or selections performed; and
- license or reuse restrictions, if any.

Priority datasets include:

- USGS lava hazard zones;
- Hawaiʻi County parcel boundaries;
- roads and evacuation routes;
- critical facilities;
- communities and administrative boundaries;
- population and socioeconomic indicators; and
- historic lava-flow footprints.

## 3. Evidence-status rules

Every quantitative statement must be assigned one of these statuses:

### Confirmed 2025 result

A result produced by the original analysis and supported by the original report, table, or GIS output.

### Updated and reproduced result

A result recalculated using identified newer datasets and a documented method.

### Context only

Background information used to explain the issue but not used to support an original quantitative conclusion.

Do not silently replace a 2025 figure with a newer number. If the analysis is rerun, retain a record of both versions and explain the difference.

## 4. Minimum content required before building

- confirmed working title;
- original final paper;
- at least one usable study-area or hazard map;
- evidence supporting the three principal parcel figures;
- preliminary dataset bibliography;
- analyst name and short professional biography; and
- decision on whether the original full report should be downloadable.

## 5. Build stages

### Stage 1 — Material review

Review the report, maps, tables, GIS files, sources, and instructor feedback. Identify what can be reused and what requires updating.

### Stage 2 — Evidence verification

Confirm the analysis method, parcel totals, zone classifications, sources, dates, and limitations. Separate current facts from historic project results.

### Stage 3 — Content blueprint

Draft and edit the English narrative for all site sections before extensive visual development.

### Stage 4 — Map plan

Decide which maps will be interactive, staged, embedded from ArcGIS Online, rebuilt with web mapping, or shown as static analytical figures.

### Stage 5 — First meaningful version

Build the opening, study-area context, and key-findings sections first so the central professional story can be evaluated early.

### Stage 6 — Policy layer

Add community exposure, equity considerations, policy comparisons, and prioritized recommendations supported by the verified evidence.

### Stage 7 — Quality assurance

Check desktop and mobile layouts, map performance, legends, labels, citations, spelling, accessibility, factual accuracy, and data-year disclosures.

### Stage 8 — Publication

Publish only after the complete site has been reviewed and approved.

## 6. Current project status

- Original paper, presentation, map exports, ArcGIS project, and file geodatabase received.
- Split geodatabase archive joined and integrity-checked successfully.
- Parcel totals and Zone 1/2 spatial-intersection results reproduced.
- Data and claims audit completed.
- Key outdated or unsupported statements identified for correction.

## 7. Immediate next action

Build the first meaningful private site version using the approved opening, hazard context, methods, verified findings, and official warning panel. The policy and analyst-profile sections can follow after the first visual review.
