param(
  [string]$ProjectRoot = 'E:\GPT projects\SpatialGround'
)

$ErrorActionPreference = 'Stop'
$SourceRoot = Join-Path $PSScriptRoot 'astro-integration'

if (-not (Test-Path (Join-Path $ProjectRoot 'package.json'))) {
  throw "Astro project not found at: $ProjectRoot"
}
if (-not (Test-Path (Join-Path $SourceRoot 'src\pages\projects\hawaii-lava-risk.astro'))) {
  throw "Integration source files not found beside this script."
}

$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$backupRoot = Join-Path $ProjectRoot ".phase1-backup\hawaii-lava-risk-$stamp"

$items = @(
  @{ Source = 'src\pages\projects\hawaii-lava-risk.astro'; Target = 'src\pages\projects\hawaii-lava-risk.astro' },
  @{ Source = 'src\styles\lava-risk.css'; Target = 'src\styles\lava-risk.css' },
  @{ Source = 'public\lava-risk'; Target = 'public\lava-risk' }
)

foreach ($item in $items) {
  $src = Join-Path $SourceRoot $item.Source
  $dst = Join-Path $ProjectRoot $item.Target

  if (Test-Path $dst) {
    $backup = Join-Path $backupRoot $item.Target
    New-Item -ItemType Directory -Force -Path (Split-Path $backup -Parent) | Out-Null
    Copy-Item $dst $backup -Recurse -Force
    Write-Host "Backed up: $($item.Target)"
  }

  New-Item -ItemType Directory -Force -Path (Split-Path $dst -Parent) | Out-Null
  if ((Get-Item $src) -is [System.IO.DirectoryInfo]) {
    if (Test-Path $dst) { Remove-Item $dst -Recurse -Force }
    Copy-Item $src $dst -Recurse -Force
  } else {
    Copy-Item $src $dst -Force
  }
  Write-Host "Installed: $($item.Target)"
}

Write-Host "`nPhase 1 files installed. No homepage/ring files were changed." -ForegroundColor Green
Write-Host "Running Astro production build...`n"

Push-Location $ProjectRoot
try {
  npm run build
  Write-Host "`nBuild passed." -ForegroundColor Green
  Write-Host "Next: npm run dev"
  Write-Host "Open: http://localhost:4321/projects/hawaii-lava-risk/"
  Write-Host "`nGit changes:"
  git status --short
}
finally {
  Pop-Location
}
