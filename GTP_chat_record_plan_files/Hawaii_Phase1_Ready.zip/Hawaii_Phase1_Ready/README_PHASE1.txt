HAWAI'I LAVA PROJECT — PHASE 1

Goal: integrate the existing Astro-ready case-study page without redesigning it.
This package does NOT alter the SpatialGround homepage or Selected Work ring.

Recommended:
1. Extract this ZIP anywhere.
2. Open PowerShell.
3. Run:
   powershell -ExecutionPolicy Bypass -File ".\integrate-phase1.ps1"

Default SpatialGround root:
E:\GPT projects\SpatialGround

If your project is elsewhere:
powershell -ExecutionPolicy Bypass -File ".\integrate-phase1.ps1" -ProjectRoot "D:\path\to\SpatialGround"

The script:
- verifies package.json exists
- backs up any existing Hawai'i route/CSS/assets before overwriting
- installs only the Phase 1 files
- runs npm run build
- prints git status

After a successful build:
cd "E:\GPT projects\SpatialGround"
npm run dev

Open:
http://localhost:4321/projects/hawaii-lava-risk/

Do not connect the homepage card or refactor global navigation yet. First confirm this baseline route matches the published prototype substantially.
